<?php
require_once('vendor/autoload.php');
use \Firebase\JWT\JWT; 
use \Firebase\JWT\Key;
include_once 'constant.php';
include_once('HTTP.php');
$http = new HTTP();
$timestamp = time();

$PT_dataArray = array(
	
	"merchantID" => MERCHANT_ID,
	"invoiceNo" => '9773',
	"locale" => 'en'
);

function base64url_encode($data) {
  return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64url_decode($data) {
  return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
}

$PT_dataArray = (object) array_filter((array) $PT_dataArray);    
$PT_data = json_encode($PT_dataArray);   


$PT_dataB64= base64url_encode($PT_data);

//JWT header
$PT_header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
$PT_headerB64= base64url_encode($PT_header);

$PT_signature= hash_hmac('sha256', $PT_headerB64 . "." . $PT_dataB64 ,SECRET_CODE, true); 
$PT_signatureB64= base64url_encode($PT_signature);

$PT_payloadData = $PT_headerB64 . "." . $PT_dataB64 . "." . $PT_signatureB64;
$PT_payloadArray = array(
	"payload" => $PT_payloadData
);
$PT_payloadArray = (object) array_filter((array) $PT_payloadArray);                 
$PT_payload = json_encode($PT_payloadArray);  

//Send request to 2C2P PGW and get back response
$PT_response = $http->post(INQUIRY,$PT_payload);
$PT_resData = json_decode($PT_response,true);
$PT_resPayload = base64_decode($PT_resData['payload']);

$decodedPayload = JWT::decode($PT_resData['payload'], new Key(SECRET_CODE, 'HS256'));
$decoded_array = (array) $decodedPayload;

echo "<pre>";
print_r($decoded_array);
die;

?>