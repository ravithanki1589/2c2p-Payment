<?php
require_once('vendor/autoload.php');
use \Firebase\JWT\JWT; 
use \Firebase\JWT\Key;
include_once 'constant.php';

$response = $_REQUEST['paymentResponse'];
//Decode response with base64
    $reponsePayLoadXML = base64_decode($response);
	
	echo "<pre>";
	print_r(json_decode($reponsePayLoadXML));
    
	/*
    //Parse ResponseXML
    $xmlObject = simplexml_load_string($reponsePayLoadXML) or die("Error: Cannot create object");
    
    //Decode payload with base64 to get the Reponse
    $payloadxml = base64_decode($xmlObject->payload);
    
    //Get the signature from the ResponseXML
    $signaturexml = $xmlObject->signature;
    
    $secretKey = SECRET_CODE;    //Get SecretKey from 2C2P PGW Dashboard

    //Encode the payload
    $base64EncodedPayloadResponse=base64_encode($payloadxml);
    //Generate signature based on "payload"
    $signatureHash = strtoupper(hash_hmac('sha256', $base64EncodedPayloadResponse ,$secretKey, false));
    
    //Compare the response signature with payload signature with secretKey
    if($signaturexml == $signatureHash){
        echo "Response :<br/><textarea style='width:100%;height:80px'>". $payloadxml."</textarea>"; 
    }
    else{
        //If Signature does not match
        echo "Error :<br/><textarea style='width:100%;height:20px'>". "Wrong Signature"."</textarea>"; 
        echo "<br/>";
    }*/
	
	/*
stdClass Object
(
    [locale] => 
    [invoiceNo] => 1708799908
    [channelCode] => CC
    [respCode] => 2000
    [respDesc] => Transaction is completed, please do payment inquiry request for full payment information.
)
*/
?>