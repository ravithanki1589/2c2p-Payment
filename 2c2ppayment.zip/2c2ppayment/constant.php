<?php
define('CALLBACKURL', 'http://localhost/Payment_gateway/2c2ppayment/success.php');
define('MERCHANT_ID', '702702000002233');
define('SECRET_CODE', '8E5B865DA760853E56FBF446876BC575544480A6F7B799067ED90C9F90E41845');
define('CURRENCY', 'SGD');
define('TOKENURL', 'https://sandbox-pgw.2c2p.com/payment/4.1/paymentToken');
define('INQUIRY', 'https://sandbox-pgw.2c2p.com/payment/4.1/paymentInquiry');

//https://pgw.2c2p.com/payment/4.1/paymentToken
//https://pgw.2c2p.com/payment/4.1/paymentInquiry
?>